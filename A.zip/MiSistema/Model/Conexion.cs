﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiSistema.Model
{
    class Conexion
    {   //VPN: IPMáquina 

        //public static string Cn = "Data Source=WALGER-PC; Initial Catalog=neptuno; Integrated Security=true";
        public static string Cn = "Data Source= DESKTOP-FF3VOHE; Initial Catalog=NuevoHotel; user=SistemaDepec; password =sistemas123";
    }
}
